# HET Consulting — Ücretsiz Statik Site Starter

Bu klasör, `het-consulting.com` alan adınızla **ücretsiz** yayınlayabileceğiniz minimal bir statik site iskeletidir.

## 1) Ücretsiz Yayınlama Yolları
- **GitHub Pages (önerilir):** Ücretsiz barındırma + özel alan adı + HTTPS.  
- **Alternatif:** Netlify/Cloudflare Pages (ücretsiz).

## 2) GitHub Pages ile Yayına Alma (özet)
1. GitHub'da yeni bir repo açın (örn. `het-consulting-site`).  
2. Bu klasörün içeriğini repoya yükleyin.  
3. Repo **Settings → Pages**:  
   - **Source:** `Deploy from a branch`  
   - **Branch:** `main` / `/ (root)`  
4. **Custom domain** alanına `het-consulting.com` yazın ve kaydedin.  
5. Alan adınızın DNS'ine şu A kayıtlarını ekleyin (apex için):  
   - `185.199.108.153`  
   - `185.199.109.153`  
   - `185.199.110.153`  
   - `185.199.111.153`  
   `www` için CNAME: `<kullaniciadiniz>.github.io`  
6. GitHub Pages'de **Enforce HTTPS** kutusunu işaretleyin.

> DNS değişiklikleri 5 dk – 24 saat arasında yayılabilir.

Kaynak: GitHub Pages belgeleri.

## 3) Düzenlemeniz Gerekenler
- `index.html` içindeki:
  - GA4 ölçüm kimliği: `G-XXXX`
  - LinkedIn Insight Tag Partner ID: `XXXXXXXX`
  - Calendly linki
  - Tally form linki (https://tally.so/)
- `privacy.html` ve `imprint.html` sayfalarında yasal metinleri doldurun.
- Görseller eklemek isterseniz `assets/` klasörüne koyup `index.html`'den referans verin.

## 4) Çerez Uyumluluğu
Bu projedeki çerez bildirimi basit bir yer tutucudur. Gerçek uyumluluk için CookieYes/Complianz gibi bir CMP kullanın.

## 5) Çok Dil (opsiyonel)
Statik sitede ikinci dil için `en/` veya `de/` klasörleri açıp kopya sayfalar oluşturabilirsiniz. WordPress'e geçmek isterseniz Polylang/TranslatePress kullanabilirsiniz.

İyi yayınlar!
