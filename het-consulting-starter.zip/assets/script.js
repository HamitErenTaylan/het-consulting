function toggleMenu(){var m=document.getElementById('menu'); m.style.display = (m.style.display==='block'?'none':'block');}
function acceptCookies(){var c=document.getElementById('cookie'); c.style.display='none'; localStorage.setItem('cookie-ok','1');}
(function(){if(localStorage.getItem('cookie-ok')==='1'){var c=document.getElementById('cookie'); if(c) c.style.display='none';}})();
